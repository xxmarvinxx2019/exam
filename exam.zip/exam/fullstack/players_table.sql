-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2022 at 05:53 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `players`
--

-- --------------------------------------------------------

--
-- Table structure for table `players_table`
--

CREATE TABLE `players_table` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `second_name` varchar(255) NOT NULL,
  `form` varchar(255) NOT NULL,
  `total_points` int(11) NOT NULL,
  `influence` varchar(255) NOT NULL,
  `creativity` varchar(255) NOT NULL,
  `threat` int(11) NOT NULL,
  `ict_index` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `players_table`
--

INSERT INTO `players_table` (`id`, `first_name`, `second_name`, `form`, `total_points`, `influence`, `creativity`, `threat`, `ict_index`) VALUES
(2, 'Simeon', 'Lord', 'sds', 23, 'wq', 'weq', 2, 2),
(3, 'james', 'reid', 'sad', 2, 'ds', 'da', 2, 2),
(4, 'Tim', 'Duncan', 'wqJersyet', 30, 'wqe', 'wqe', 2, 2),
(5, 'Simeon', 'Lords', 'wqe', 2, 'qwe', '2', 2, 0),
(6, '\'tim', 'lod', 'asd', 2, 'wqe', 'wqe', 2, 1),
(7, 'loss', 'site', 'ds', 3, 'ewr', 'ewr', 3, 3),
(8, 'ere', 'sad', 'asd', 2, 'wq', 'wqe', 2, 2),
(9, 'raid', 'aer', 'qwe', 23, 'ewq', '2wqe', 2, 2),
(10, 'miki', 'sad', 'asd', 22, 'ew', 'wqe', 34, 23),
(11, 'Marv', 'ad', 'sad', 44, 'dsf', '3dsf', 34, 66),
(12, 'Marv', 'ad', 'sad', 44, 'dsf', '3dsf', 34, 66),
(13, 'wqe', 'ww', 'wwe', 2, '2wd', 'we', 2, 2),
(14, 'weq', 'wqe', 'wqe', 2, '2', 'we2', 2, 2),
(15, 'Hakari', 'Juu', 'west', 22, 'ee', 'nothing', 99, 99),
(16, 'new', 'players', 'dsa', 2, 'ew', '23', 23, 23),
(17, 'kim', 'cam', 'sd', 23, 'wsd', 'qwe', 29, 29),
(18, 'we', 'wqe', 'wqe', 23, '23', '32', 23, 23),
(19, 'play asd', 'play', 'www', 23, 'sd', 'eq', 55, 4122),
(20, 'players', 'asd', 'ew', 223, 'wqe', 'qr', 23, 23),
(21, 'Tim', 'james', 'sdd', 20, 'we', 'we', 20, 20),
(22, 'news', 'sad', 'sad', 23, '42sa', 'd', 23, 22),
(23, 'Marvins', 'gg', 'sad', 23, 'sad', 'dd', 23, 23),
(24, 'ret', 'wqe', 'wqe', 23, '23', 'weq', 2, 23),
(25, 'juju', 'io', 'wqe', 22, 'qeqw', 'wqewqe', 44, 2323),
(26, 'haha', 'hshsh', 'we', 80, '99w', 'we', 9, 9),
(27, 'jaja', 'uy', 'we', 20, '2sqd', 'wqe', 90, 90),
(28, 'add', 'leaev', 'we', 8, 'e', 'we', 10, 10),
(29, 'sasuke', 'uchiha', 'sd', 20, 'wqe', 'qwe', 20, 20),
(30, 'alan', 'asd', 'we', 2, 'wqe', 'we', 2, 2),
(31, 'ow', 'we', 'we', 90, 'weq', 'weq', 90, 9),
(32, 'cheetos', 'sad', 'sad', 23, 'er', 'weqqr', 1, 22),
(33, 'bonnie', 'cylde', 'da', 90, 'SDQ', 'QWE', 29, 2),
(34, 'ZEUS', 'DF', 'dfs', 88, 'df', 'ewe', 88, 88),
(35, 'first', 'last', 'sd', 78, 'wr', 'we', 78, 78),
(36, 'ses', 'ds', 'we', 20, '2sad', '2sad', 20, 20),
(37, 'gg', 'gg', 'qe', 9, 'e', 'we', 9, 9),
(38, 'yol', 'ww', 'qew', 10, 'wqe', 'qwe', 2, 2),
(39, 'trais', 'trai', 'das', 2, 'we', 'ewr', 2, 3),
(40, 'hey', 'fhw', 'ew', 20, 'we', 'we', 20, 22),
(41, 'des', 'mond', 'sad', 20, 'ew', 'qwe', 20, 20),
(42, 'oh no', 'oh no', 'da', 22, 'wre', 'ewr', 22, 22),
(43, 'ty', 'ty', 'wer', 100, 'ewr', 'ewr', 2100, 220),
(44, 'yet', 'ewr', 'er', 20, 'er', 'ewr', 4, 4),
(45, 'dx', 'army', 'sd', 555, 'er', 'er', 999, 999),
(46, 'red', 'blue', 'rrro', 9, 'ewr', 'rew', 9, 9),
(47, 'that', 'its', 'ee', 55, 'eei', 'er', 3, 4),
(48, 'degerna', 'ert', 'wqe', 9, 'qwer', 'we', 9, 9),
(49, 'git', 'git', 'df', 0, 'dfs', '9', 9, 9),
(50, 'blis', 'asd', 'dgg', 9, '9ewer', '9', 9, 9),
(51, 'newss', 'dfw7', 'dfds', 9, 'dff', '009', 9, 9),
(52, 'freea', 'asd', 'gd', 3, '3', '3', 3, 3),
(53, 'jhjhj', 'dsf', '99', 99, 'dwf', 'dfs', 1999, 299),
(54, 'almost', 'ther', 'dfs', 33, 'ewr', 'rwe', 34, 34),
(55, 'yuri', 'sad', 'ee', 22, 'er', 'wqe2', 2, 2),
(56, 'hana', 'rweerr', 'ewrwe', 2, '2', '2', 2, 2),
(57, 'loid', 'forger', 'ewr', 90, '9er', '9', 90, 9),
(58, 'anya', 'er', 'ewrsd', 9, '9', '9', 9, 9),
(59, 'fast', 'fast', 'trrt', 99, 'er', 'er', 99, 99),
(60, 'hey', 'go', 'sdfdf', 9, 'sdf', 'dsf', 9, 9),
(61, 'gty', 'dfdg', 'dfsd', 9, '9', '9', 9, 9),
(62, 'gord', 'asd', 'df', 2, '2', '2', 2, 2),
(63, 'aw', 'we', 'wq', 2, '2', '2', 2, 2),
(64, 'Maxwell', 'dsd', 'df', 90, 'r', 'ewqr', 90, 9),
(65, 'uy', 'adf', 'er', 90, 'edr', 'er', 90, 9),
(66, 'gy', 'dsf', 'dfg', 55, 'wd', 'er', 6, 4),
(67, 'huy', 'dsfdf', 'ds', 99, 'f', '9', 9, 9),
(68, 'mjf', 'mj', 'sdfl', 7, '7', '7', 7, 7),
(69, 'tot', 'dsf', 'dsf', 9, '9', '9', 9, 9),
(70, 'hut', 'red', 'sadf', 88, 'dsf', 'dsf', 88, 8),
(71, 'ggo', 'dfo', 'er', 9, '9', '9', 9, 9),
(72, 'malapi', 'sdf', 'sdg', 8, '8', '8', 8, 8),
(73, 'yehey', 'yojj', 'dsf', 88, '8', '8', 8, 8),
(74, 'think', 'fast', 'f', 9, '9', '9', 9, 9),
(75, 'now now', 'dasfd', 'dsf', 88, 'wr', 'er', 88, 8),
(76, 'haha', 'dkdk', 'ddg', 98, 'dr', 'ewr', 933, 39),
(77, 'whwt', 'what', 'oi', 87, 'wer', 'er', 9, 9),
(78, 'tri', 'eri', 'wer', 8, 'er8', '8', 8, 8),
(79, 're', 'er', 'er', 87, 'er', 'er', 90, 90),
(80, 'job', 'offer', 'er', 90, 'er', 'er', 90, 90),
(81, 'hope', 'faith', 'dsf', 88, 'er', 'er', 88, 88),
(82, 'hmm', 'dsf', 'ie', 90, 'er', 're', 90, 8),
(83, 'hard', 'bass', 'd', 99, 'er', '9', 9, 9),
(84, 'hg', 'gd', 'dsg', 9, '9', '9', 9, 9),
(85, 'thanos', 'ironman', 'ew', 5, '5', '7', 7, 7),
(86, 'er', 'ert', 'et', 3, '3', '3', 3, 3),
(87, 'yes', 'yes', 'no', 9, '9', '9', 9, 9),
(88, 'gt', 'it', 'ddgg', 9, '9', '9', 9, 9),
(89, 'ew', 'we', 'er', 99, '9', '9', 9, 9),
(90, 'we', 'err', 'err', 8, '8', '8', 8, 8),
(91, 'yyt', 'er', 'er', 88, '8', '8', 8, 8),
(92, 'sana', 'all', 'nalnag', 3, '3', '3', 3, 3),
(93, 'thirssdf', 'df', 'ge', 9, '9', '9', 9, 9),
(94, 'whys', 'though', 'dsf', 9, '8', '8', 8, 7),
(95, 'hmmn', 'df', 'tew', 99, '99', '9', 9, 9),
(96, 'heyeyh', 'et', 'er', 8, '8', '8', 8, 8),
(97, 'sht', 'sf', 'dsf', 86, '7', '8', 7, 7),
(98, 'go', 'go', 'gsd', 33, '333', '3', 3, 3),
(99, 'fs', 'ewr', '34', 23, '23', '2', 2, 2),
(100, 'yu', 'er2', '34ewr', 8, '9', '9', 9, 9),
(101, 'weak', 'ewr', 'er', 9, '9', '9', 9, 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `players_table`
--
ALTER TABLE `players_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `players_table`
--
ALTER TABLE `players_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
