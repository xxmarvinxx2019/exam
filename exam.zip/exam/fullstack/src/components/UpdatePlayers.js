import {Container,Box,TextField,Paper,Button,Alert,AlertTitle,Collapse} from '@mui/material'
import {useState,useEffect} from 'react';
import axios from 'axios';
import { useNavigate,Link,useParams } from 'react-router-dom';
import ModeEditIcon from '@mui/icons-material/ModeEdit';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';


export default function UpdatePlayers() {
    const [input,setInputs] = useState({});
    const [open,setOpen] = useState(false)
    const history = useNavigate();
    const params = useParams();
    const [players,setPlayers] = useState({})

    console.log(params.id);
    const [input1,setInputs1] = useState({id:1});
    const handleInput = (events) => {
        const name = events.target.name;
        const value = events.target.value;
        setPlayers(values => ({...values,[name]:value}));
    }

    useEffect(() => {
        getPlayer();
    },[]);
    /*Handle Update players */
    const sub = (event) => {
        event.preventDefault();
        axios.post('http://localhost/dbplayers/api/update_player.php',players).then(function (response) {
            console.log(response);
            if(response.data.success == 1){
                setOpen(true)

                if(input != ''){
                    setTimeout(() => {
                        setOpen(false);
                        history('/')
                      }, 3000);
                }
                /*history('/')*/
                 
            }
        })
        .catch(function (error) {
            console.log(error);
        });
    }
    function getPlayer(){
        axios.get(`http://localhost/dbplayers/api/get_single_player.php/${params.id}`).then(function (response) {
          console.log(response.data.users[0]);
          setPlayers(response.data.users[0])
        })
    }
    return (
        <Container>
            <Box mt={3}>
            <Collapse in={open}>
                <Alert severity="success">
                    <AlertTitle>Success</AlertTitle>
                        Players Updated <strong>check it out!</strong>
                </Alert>
            </Collapse>
            </Box>
            <Box component={Paper} p={2} spacing={2} mt={4}
                sx={{
                width: 500,
                maxWidth: '100%',
                display: 'grid',
              }}
            >
                <Box mt={1}>
                    <Box sx={{ fontSize: 30}}>Update Players</Box>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" value={players.first_name} defaultValue="sad" label="First Name" name="first_name" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" value={players.second_name} defaultValue="sad" label="Last Name" name="second_name" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" value={players.form} defaultValue="sad" label="Form" name="form" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }}>
                    <TextField id="outlined-basic" value={players.total_points} defaultValue="sad" label="Total points" name="total_points" variant="outlined" onChange={handleInput}/>
                    <TextField id="outlined-basic" value={players.influence} defaultValue="sad" label="Influence" name="influence" variant="outlined" onChange={handleInput}/>
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }}>
                    <TextField id="outlined-basic" value={players.creativity} defaultValue="sad" label="Creativity" name="creativity" variant="outlined"  onChange={handleInput}/>
                    <TextField id="outlined-basic" value={players.threat} defaultValue="sad" ml={2} label="Threat" name="threat" variant="outlined"  onChange={handleInput}/>
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" value={players.ict_index} defaultValue="sad" label="ICT Index" name="ict_index" variant="outlined" fullWidth onChange={handleInput}/>
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }} >
                    <Button startIcon={<ModeEditIcon/>} variant="contained" onClick={sub} >Update</Button>
                    <Button startIcon={<KeyboardBackspaceIcon/>} variant="contained" component={Link} to="/" color="secondary">Cancel</Button>
                </Box>
            </Box>
        </Container>
    )
}