import {Container,Box,TextField,Paper,Button,Alert,AlertTitle,Collapse} from '@mui/material'
import {useState} from 'react';
import axios from 'axios';
import { useNavigate,Link } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SaveAsIcon from '@mui/icons-material/SaveAs';


export default function CreatePlayer() {
    const [input,setInputs] = useState({});
    const [open,setOpen] = useState(false)
    const [errorFirst,setErrorFirst] = useState(false)
    const [errorFirstname,setErrorFirstName] = useState("");
    const [errorSecond,setSecond] = useState(false)
    const [errorSecondname,setErrorSecondName] = useState("");
    const [errorThird,setThird] = useState(false)
    const [errorForm,setErrorForm] = useState("");
    const [errorFourth,setFourth] = useState(false);
    const [errorTotalPoints,setTotalPoints] = useState("")
    const [errorFifth,setFifth] = useState(false);
    const [errorInfluence,setInfluence] = useState("");
    const [errorSixth,setSixth] = useState(false)
    const [errorCreativity,setCreativity] = useState("")
    const [errorSeven,setSeven] = useState(false)
    const [errorThreat,setThreat] = useState("")
    const [errorEight,setEight] = useState(false)
    const [errorICT,setICT] = useState("")

    const history = useNavigate();
    /*Handle the inputs */
    const handleInput = (events) => {
        const name = events.target.name;
        const value = events.target.value;
        setInputs(values => ({...values,[name]:value}));
        if(events.target.name === "first_name"){
            setErrorFirstName(events.target.value)
        }
        if(events.target.name === "second_name"){
            setErrorSecondName(events.target.value)
        }
        if(events.target.name === "form"){
            setErrorForm(events.target.value)
        }
        if(events.target.name === "total_points"){
            setTotalPoints(events.target.value)
        }
        if(events.target.name === "influence") {
             setInfluence(events.target.value) 
        }
        if(events.target.name === "creativity"){
            setCreativity(events.target.value)
        }
        if(events.target.name === "threat"){
            setThreat(events.target.value)
        }
        if(events.target.name === "ict_index"){
            setICT(events.target.value)
        }
    }
    /* Handle save data to database */
    const handleSubmit = () => {
        if(errorFirstname === ''){
            setErrorFirst(true)
            console.log(input)
        }
        if(errorSecondname === ""){
            setSecond(true)
        }
        if(errorForm === ""){
            setThird(true)
        }
        if(errorTotalPoints === ""){
            setFourth(true)
        }
        if(errorInfluence === ""){
            setFifth(true)
        }
        if(errorCreativity === ""){
            setSixth(true)
        }
        if(errorThreat === ""){
            setSeven(true)
        }
        if(errorICT === ""){
            setEight(true)
        }
        else{

        axios.post('http://localhost/dbplayers/api/create_players.php',input).then(function (response) {
            console.log(response.data);
            console.log(input)
            if(response.data.success == 1){
                setOpen(true)
                if(input != ''){
                    setTimeout(() => {
                        setOpen(false);
                        history('/')
                      }, 3000);
                }
                /*history('/')*/
                 
            }
        })
        .catch(function (error) {
            console.log(error);
        });
        }
    }
    return (
        <Container>
            <Box mt={3}>
            <Collapse in={open}>
                <Alert severity="success">
                    <AlertTitle>Success</AlertTitle>
                        Player Added <strong>check it out!</strong>
                </Alert>
            </Collapse>
            </Box>
            <Box component={Paper} p={2} spacing={2} mt={4}
                sx={{
                width: 500,
                maxWidth: '100%',
                display: 'grid',
              }}
            >
                <Box mt={1}>
                    <Box sx={{ fontSize: 30}}>Create New Players</Box>
                </Box>
                <form onSubmit={handleSubmit}>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="First Name" name="first_name" variant="outlined" fullWidth onChange={handleInput}/>
                    {errorFirst ? <p style={{color:'red'}}>Please input First Name *</p> : <></>}
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="Last Name" name="second_name" variant="outlined" fullWidth onChange={handleInput}/>
                    {errorSecond ? <p style={{color:'red'}}>Please input Last Name *</p> : <></>}
                </Box>
                <Box mt={2}>
                    <TextField id="outlined-basic" label="Form" name="form" variant="outlined" fullWidth onChange={handleInput}/>
                    {errorThird ? <p style={{color:'red'}}>Please input Form *</p> : <></>}
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }}>
                    <TextField type="number" id="outlined-basic" label="Total points" name="total_points" variant="outlined" onChange={handleInput}/>
                    <TextField id="outlined-basic" label="Influence" name="influence" variant="outlined" onChange={handleInput}/>
                </Box>
                <Box sx={{ display: 'flex',justifyContent: 'space-between' }}>
                    {errorFourth ? <p style={{color:'red'}}>Please input Total points *</p> : <></>}
                    {errorFifth ? <p style={{color:'red'}}>Please input Influence *</p> : <></>}
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }}>
                    <TextField id="outlined-basic" label="Creativity" name="creativity" variant="outlined"  onChange={handleInput}/>
                    <TextField type="number" id="outlined-basic" ml={2} label="Threat" name="threat" variant="outlined"  onChange={handleInput}/>
                </Box>
                <Box sx={{ display: 'flex',justifyContent: 'space-between' }}>
                    {errorSixth ? <p style={{color:'red'}}>Please input Creativity *</p> : <></>}
                    {errorSeven ? <p style={{color:'red'}}>Please input Threat *</p> : <></>}
                </Box>
                <Box mt={2}>
                    <TextField type="number" id="outlined-basic" label="ICT Index" name="ict_index" variant="outlined" fullWidth onChange={handleInput}/>
                    {errorEight ? <p style={{color:'red'}}>Please input ICT Index *</p> : <></>}
                </Box>
                <Box mt={2} sx={{ display: 'flex',justifyContent: 'space-between' }} >
                    <Button startIcon={<SaveAsIcon/>} variant="contained" onClick={handleSubmit}>Submit</Button>
                    <Button startIcon={<ArrowBackIcon/>} variant="contained" component={Link} to="/" color="success">Cancel</Button>
                </Box>
                </form>
            </Box>
        </Container>
    )
}