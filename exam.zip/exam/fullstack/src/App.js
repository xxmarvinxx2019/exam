import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import ListPlayers from './components/ListPlayers';
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import CreatePlayer from './components/CreatePlayer';
import UpdatePlayers from './components/UpdatePlayers';

function App() {
  return (
    <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path="/" element={<ListPlayers/>} />
        <Route path="/create" element={<CreatePlayer/>}/>
        <Route path="/edit/:id" element={<UpdatePlayers/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
