<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db_connection.php';

$data = json_decode(file_get_contents("php://input"));

$path = explode('/', $_SERVER['REQUEST_URI']);
$allUsers = mysqli_query($db_conn, "SELECT * FROM `players_table` where `id` = '$path[4]'");
if (mysqli_num_rows($allUsers) > 0) {
    $all_users = mysqli_fetch_all($allUsers, MYSQLI_ASSOC);
    echo json_encode(["success" => 1, "users" => $all_users]);
    /*echo json_encode([$delID]);*/
} else {
    echo json_encode(["success" => 0,"users" => $path[4]]);
}
