<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db_connection.php';

// POST DATA
$data = json_decode(file_get_contents("php://input"));

if (
    isset($data->first_name)
    && isset($data->second_name)
    && isset($data->form)
    && isset($data->total_points)
    && isset($data->influence)
    && isset($data->creativity)
    && isset($data->threat)
    && isset($data->ict_index)
    && !empty(trim($data->first_name))
    && !empty(trim($data->second_name))
    && !empty(trim($data->form))
    && !empty(trim($data->total_points))
    && !empty(trim($data->influence))
    && !empty(trim($data->creativity))
    && !empty(trim($data->threat))
    && !empty(trim($data->ict_index))
) {
    $first_name = mysqli_real_escape_string($db_conn, trim($data->first_name));
    $second_name = mysqli_real_escape_string($db_conn, trim($data->second_name));
    $form = mysqli_real_escape_string($db_conn, trim($data->form));
    $total_points = mysqli_real_escape_string($db_conn, trim($data->total_points));
    $influence = mysqli_real_escape_string($db_conn, trim($data->influence));
    $creativity = mysqli_real_escape_string($db_conn, trim($data->creativity));
    $threat = mysqli_real_escape_string($db_conn, trim($data->threat));
    $ict_index = mysqli_real_escape_string($db_conn, trim($data->ict_index));
    
    $allUsers = mysqli_query($db_conn, "SELECT * FROM `players_table` where `first_name` = '$first_name' AND `second_name` = '$second_name' ");
    if (mysqli_num_rows($allUsers) > 0) {
        $all_users = mysqli_fetch_all($allUsers, MYSQLI_ASSOC);
        echo json_encode(["success" => 2, "msg" => "duplicate data"]);
    /*echo json_encode([$delID]);*/
    } else {

        $insertUser = mysqli_query($db_conn, "INSERT INTO `players_table`(`first_name`,`second_name`,`form`,`total_points`,`influence`,`creativity`,`threat`,`ict_index`) VALUES('$first_name','$second_name','$form','$total_points','$influence','$creativity','$threat','$ict_index')");
        if ($insertUser) {
            $last_id = mysqli_insert_id($db_conn);
            echo json_encode(["success" => 1, "msg" => "User Inserted.", "id" => $last_id]);
        } else {
            echo json_encode(["success" => 0, "msg" => "User Not Inserted!"]);
        }
    }
} else {
    echo json_encode(["success" => 0, "msg" => "Please fill all the required fields!"]);
}