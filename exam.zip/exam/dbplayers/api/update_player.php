<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db_connection.php';

$data = json_decode(file_get_contents("php://input"));

if (
    isset($data->id)
    && isset($data->first_name)
    && isset($data->second_name)
    && isset($data->form)
    && isset($data->total_points)
    && isset($data->influence)
    && isset($data->creativity)
    && isset($data->threat)
    && isset($data->ict_index)
    && !empty(trim($data->first_name))
    && !empty(trim($data->second_name))
    && !empty(trim($data->form))
    && !empty(trim($data->total_points))
    && !empty(trim($data->influence))
    && !empty(trim($data->creativity))
    && !empty(trim($data->threat))
    && !empty(trim($data->ict_index))
) {
    $first_name = mysqli_real_escape_string($db_conn, trim($data->first_name));
    $second_name = mysqli_real_escape_string($db_conn, trim($data->second_name));
    $form = mysqli_real_escape_string($db_conn, trim($data->form));
    $total_points = mysqli_real_escape_string($db_conn, trim($data->total_points));
    $influence = mysqli_real_escape_string($db_conn, trim($data->influence));
    $creativity = mysqli_real_escape_string($db_conn, trim($data->creativity));
    $threat = mysqli_real_escape_string($db_conn, trim($data->threat));
    $ict_index = mysqli_real_escape_string($db_conn, trim($data->ict_index));
        $updateUser = mysqli_query($db_conn, "UPDATE `players_table` SET `first_name`='$first_name', `second_name`='$second_name',`form`='$form',
                                        `total_points`='$total_points',`influence`='$influence',`creativity`='$creativity',`threat`='$threat',`ict_index`='$ict_index' WHERE `id`='$data->id'");
        if ($updateUser) {
            echo json_encode(["success" => 1, "msg" => "User Updated."]);
        } else {
            echo json_encode(["success" => 0, "msg" => "User Not Updated!"]);
        }
} else {
    echo json_encode(["success" => 0, "msg" => "Please fill all the required fields!"]);
}